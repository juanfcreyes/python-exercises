import sys
if (len(sys.argv) > 1):
    print(int(sys.argv[1]) + int(sys.argv[2]))
else:
    print("Not arguments")
